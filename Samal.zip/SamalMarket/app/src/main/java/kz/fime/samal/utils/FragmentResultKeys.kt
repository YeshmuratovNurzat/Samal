package kz.fime.samal.utils

class FragmentResultKeys {

    companion object {

        const val CHANGE_NUMBER_REQUEST_KEY = "CHANGE_NUMBER_REQUEST_KEY"
        const val CHANGE_NUMBER_BUNDLE_KEY = "CHANGE_NUMBER_BUNDLE_KEY"

        const val CHANGE_NAME_REQUEST_KEY = "CHANGE_NAME_REQUEST_KEY"
        const val CHANGE_NAME_BUNDLE_KEY = "CHANGE_NAME_BUNDLE_KEY"

        const val CHANGE_EMAIL_REQUEST_KEY = "CHANGE_EMAIL_REQUEST_KEY"
        const val CHANGE_EMAIL_BUNDLE_KEY = "CHANGE_EMAIL_BUNDLE_KEY"

        const val CHANGE_PHOTO_REQUEST_KEY = "CHANGE_PHOTO_REQUEST_KEY"
        const val CHANGE_PHOTO_BUNDLE_KEY = "CHANGE_PHOTO_BUNDLE_KEY"

    }

}