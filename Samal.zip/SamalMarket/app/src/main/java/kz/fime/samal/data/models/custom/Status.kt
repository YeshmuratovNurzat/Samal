package kz.fime.samal.data.models.custom

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
