package kz.fime.samal.ui.welcome.adapters

import androidx.annotation.DrawableRes

data class Card(
        val resId: Int,
        val size: Int
)
