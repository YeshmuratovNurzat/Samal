package kz.fime.samal.data.models

data class Review(
    val name: String?,
    val photo: String?,
    val rating: Float?,
    val comment: String?,
    val created_at: String?
)