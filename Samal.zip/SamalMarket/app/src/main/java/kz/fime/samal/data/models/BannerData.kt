package kz.fime.samal.data.models

data class BannerData(
    val title: String,
    val banners: List<Banner>
)