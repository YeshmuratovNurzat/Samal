package kz.fime.samal.data.models

data class FaqResponse(
    val data: List<FaqItem>
)