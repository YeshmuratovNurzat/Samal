package kz.fime.samal.ui.profile.orders

data class ProductItem(
    val name: String,
    val cost: Int,
    val count: Int
)