package kz.fime.samal.data.models.order_detail

data class Status(
    val color: String,
    val name: String,
    val slug: String,
    val status_id: Int
)