package kz.fime.samal.data.models

data class PickUpAddress(
    val address: String,
    val name: String,
)
