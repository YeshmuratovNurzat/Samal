package kz.fime.samal.data.models.order_detail

data class Property(
    val name: String,
    val value: String
)