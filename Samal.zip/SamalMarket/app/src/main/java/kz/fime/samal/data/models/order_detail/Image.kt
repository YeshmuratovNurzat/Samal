package kz.fime.samal.data.models.order_detail

data class Image(
    val link: String,
    val type: String
)