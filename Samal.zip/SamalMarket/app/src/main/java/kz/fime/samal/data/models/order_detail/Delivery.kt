package kz.fime.samal.data.models.order_detail

data class Delivery(
    val delivery_id: Int,
    val name: String,
    val slug: String
)