package kz.fime.samal.data.models

data class Image(
    val type: String?,
    val url: String?
)
