package kz.fime.samal.data.models

data class SearchRequest(
    val text: String
)