package kz.fime.samal.data.models

data class City(
    val city_id: String,
    val name: String?,
    val slug: String,
    val timezone: String,
    val latitude: String,
    val longitude: String,

)