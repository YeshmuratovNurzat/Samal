package kz.fime.samal.ui.welcome.adapters

data class WelcomeInfo(
        val title: String?,
        val content: String?
)
