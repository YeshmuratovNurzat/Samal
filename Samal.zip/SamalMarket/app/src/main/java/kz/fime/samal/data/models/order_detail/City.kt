package kz.fime.samal.data.models.order_detail

data class City(
    val city_id: Int,
    val name: String,
    val slug: String
)