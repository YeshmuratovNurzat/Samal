package kz.fime.samal.data.models

data class BaseResponse(
        val status: String,
        val message: String
)