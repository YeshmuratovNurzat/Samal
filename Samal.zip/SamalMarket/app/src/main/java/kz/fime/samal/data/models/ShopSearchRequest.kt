package kz.fime.samal.data.models

data class ShopSearchRequest(
    val search: String
)